
package punto3;

import java.util.Scanner;

public class codigo3 {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        double suma=0;
        double suma2=0;
        double pagosemanal=0;
        double pagosemanal2=0;
        int [] ganancia=new int[7];
        for (int i = 0; i < 7; i++) {
            System.out.println("ingrese cuanto gano en el dia "+(i+1)+" :");
            ganancia[i]=leer.nextInt();
        }
        for (int x = 0; x < 7 ; x++) {
            suma += ganancia[x];
            
        }
     
        //categotia A
        if (suma>3000 && suma<5000){
            double multi;
            multi=(suma*0.05);
            pagosemanal=suma+multi+200;
            System.out.println("el pago semanal del empleado de la categoria A es: "+pagosemanal);            
        }
        else if (suma>=5000 && suma<= 7000){
            double multi2=suma*0.07;
            pagosemanal=suma+multi2*200;
            System.out.println("el pago semanal del empleado de la categoria A es: "+pagosemanal);    
        }
        else if (suma>7000){
            double multi3=suma*0.010;
            pagosemanal=suma+multi3+200;
            System.out.println("el pago semanal del empleado de la categoria A es: "+pagosemanal);
        } 
        //categaria B
        suma2=suma;
        if(suma2>5000 && suma2<10000){
            double multi4=suma2*0.07;
            pagosemanal2=suma2+multi4*200;
            System.out.println("el pago semanal del empleado de la categoria B es: "+pagosemanal2);
        }
        else if (suma2>=10000 && suma2<=15000){
            double multi5=suma2*0.010;
            pagosemanal2=suma2+multi5+200;

            System.out.println("el pago semanal del empleado de la categoria B es: "+pagosemanal2);
        }
        else if (suma2>15000){
            double mutli6=suma2*0.013;
            pagosemanal2=suma2+mutli6+200;
            System.out.println("el pago semanal del empleado de la categoria B es: "+pagosemanal2);
        }

        
   
  
    }
    
}
