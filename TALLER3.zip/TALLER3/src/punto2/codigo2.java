
package punto2;

public class codigo2 {
    public static void main(String[] args) {
        int [] saldoiniciodelmes={3000000,1500000,2000000};
        int [] totalabonomes={50000,120000,50000};
        int [] totaldeduciones={120000,56000,76000};
        final int limite_credito=8000000;
        int [] nuevo_saldo=new int [3]; 
        
        for (int i = 0; i < 3; i++) {
            nuevo_saldo[i]=saldoiniciodelmes[i]+totalabonomes[i]-totaldeduciones[i];
            if (nuevo_saldo[i]>limite_credito){
                System.out.println("Se excedió el límite de su crédito");
                
            }
        System.out.println("el nuevo balance es: "+nuevo_saldo[i]);
  
        }

    }
    
}

