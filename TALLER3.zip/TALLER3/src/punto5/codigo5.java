package punto5;


public class codigo5 {
    
    
    
    public static void main(String args[]) {
		int columna;
		int i;
		int matrix[][];
		matrix = new int[5][4];
		matrix[0][0] = 194;
		matrix[0][1] = 48;
		matrix[0][2] = 206;
		matrix[0][3] = 45;
		matrix[1][0] = 180;
		matrix[1][1] = 20;
		matrix[1][2] = 320;
		matrix[1][3] = 16;
		matrix[2][0] = 221;
		matrix[2][1] = 90;
		matrix[2][2] = 140;
		matrix[2][3] = 20;
		matrix[3][0] = 432;
		matrix[3][1] = 50;
		matrix[3][2] = 821;
		matrix[3][3] = 14;
		matrix[4][0] = 820;
		matrix[4][1] = 61;
		matrix[4][2] = 946;
		matrix[4][3] = 18;
		columna = 0;int sumafila = 0;
                double sumafila2 = 0, sumafila3 = 0, sumafila4 = 0, sumafila5 = 0;
                double sumatotalfila = 0;
                double porcentaje = 0, porcentaje2 = 0, porcentaje3 = 0, porcentaje4 = 0;
		System.out.println("Columna   "+"Candidato A   "+"Candidato B   "+"Candidato C   "+"Candidato D   ");
		for (i=1;i<=5;i++) { 
                    
			columna = columna+1;
			System.out.println("   "+columna+"         "+matrix[i-1][0]+"           "+matrix[i-1][1]+"            "+matrix[i-1][2]+"             "+matrix[i-1][3]);
                   
                        
                        sumafila += matrix[i -1 ][0] ;
                        sumafila2 += matrix[i - 1][1];
                        sumafila3 += matrix[i - 1][2];
                        sumafila4 += matrix[i - 1][3];
                        sumatotalfila=sumafila+sumafila2+sumafila3+sumafila4;

 
                       
                    
		}
                System.out.println("\n" );
                    System.out.println("*---------------------------------------------------------------------------*");
                    System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO A ES DE = "+sumafila);
                    System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO B ES DE = "+sumafila2);
                    System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO C ES DE = "+sumafila3);
                    System.out.println(" LA SUMA DE LOS VOTOS DEL CANDIDATO D ES DE = "+sumafila4);
                    System.out.println(" EL CANDIDATO CON MAS VOTOS ES EL CANIDATO C CON UN TOTAL DE = "+sumafila3+" VOTOS");
                    
                      porcentaje = sumafila*100/sumatotalfila; 
                      porcentaje2 = sumafila2*100/sumatotalfila;
                      porcentaje3 = sumafila3*100/sumatotalfila;
                      porcentaje4 = sumafila4*100/sumatotalfila;
                    System.out.println("*---------------------------------------------------------------------------*");
                    System.out.printf(" %n EL PORCENTAJE DE VOTACIONES DEL CANTIDATO A ES DE = %.2f", porcentaje );
                    System.out.printf(" %n EL PORCENTAJE DE VOTACIONES DEL CANTIDATO B ES DE = %.2f", porcentaje2 );
                    System.out.printf(" %n EL PORCENTAJE DE VOTACIONES DEL CANTIDATO C ES DE = %.2f", porcentaje3 );
                    System.out.printf(" %n EL PORCENTAJE DE VOTACIONES DEL CANTIDATO D ES DE = %.2f", porcentaje4 );
                    System.out.println("\n" );
                    System.out.println("*----------------------------------------------------------------------------*");
                    System.out.println(" EL GANADOR DE LA VOTACIONES HA SIDO  EL CANDIDATO C\n PORQUE SUS PROCENTAJE DE VOTOS PASA EL 50% ");
                    System.out.println("*----------------------------------------------------------------------------*");
                    for (int y = 0; y < matrix.length; y++) {
                        int sumas = 0;
                        for (int x = 0; x < matrix[y].length; x++) {
                             System.out.printf("%d ", matrix[y][x]);
                             sumas += matrix[y][x];
                         }
                        System.out.printf("= %d\n", sumas);
                        
                    }   System.out.println("LA COMUNA QUE MAS PORCENTAJE DE VOTACION TUVO FUE LA 5");
           
	}

    
           
    
}