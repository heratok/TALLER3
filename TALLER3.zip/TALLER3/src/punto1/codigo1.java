
package punto1;

import java.util.Scanner;

public class codigo1 {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        System.out.print("ingrese el espacio de los vectores: ");
        int limitevect=leer.nextInt();
        int [] vectorA=new int[limitevect];
        int [] vectorB=new int[limitevect];
        int [] vectorC=new int[limitevect];
        int [] vectorD=new int[limitevect];
        int i;
        int suma=0;
        int suma2=0;

       
        for ( i = 0; i < limitevect; i++) {
            System.out.printf("introduzca el codigo del producto: "+(i+1)+": ");
            vectorA[i]=leer.nextInt();
        }
        for ( i = 0; i< limitevect; i++) {
            System.out.printf("intoduzca el valor de venta del producto: "+(i+1)+": ");
            vectorB[i]=leer.nextInt();
        }        
        for ( i = 0; i < limitevect; i++) {
            System.out.printf("ingrese la cantidad de unidades vendidas: "+(i+1)+": ");
            vectorC[i]=leer.nextInt();
            
        } 
        for ( i = 0; i < vectorC.length; i++) {
            suma2 += vectorC[i]; //Total productos vendidos en el día.
            
            
        }
        for ( i = 0; i < vectorD.length; i++) {
            vectorD[i]=vectorB[i]*vectorC[i]; //calcular el Total ingresos por ventas del día.
            suma += vectorD[i]; //Total ingresos por ventas del día.
        }
        
        // El producto más vendido.    
        int mayor,menor;
        int produtmaxven=-1;
        mayor=menor=vectorC[0];
        for (int m = 0; m < vectorC.length; m++) {
            if (vectorC[m]>mayor){
                mayor=vectorC[m];
                produtmaxven=m;
            }    
        }
        //hallar El producto más costoso vendido.
        int mayor2,menor2;
        mayor2=menor2=vectorB[0];
        for (int n = 0; n < vectorB.length; n++) {
            if(vectorB[n]>mayor2){
                mayor2=vectorB[n];
            }
        }
        System.out.println("El total de vendidos en el dia es: "+suma2);
        System.out.println("El total de ingresos por ventas del dia es: "+suma);
        System.out.println("El producto "+(produtmaxven+1)+" fue el mas vendido");
        System.out.println("El producto mas costoso vendido es: "+mayor2);
        
    }
    
}
