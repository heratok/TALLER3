
package punto4;



public class codigo4 {
    public static void main(String[] args) {
        int tarifa_normaL=50000;
        final int hora=40;
        int tarifa_media=0;
        int tarifaplus=0;
        int hora_extra=0;
        int sueldo_total = 0;
        String [] vectorE={"hector","ismael","diego"}; //arreglo E con los nombres de los empleados de la empresa
        int [] vectorH={90,32,120}; //arreglo H con el número de horas que trabajó cada uno en la semana
        int [] vectorT=new int [3]; //arreglo T con la tarifa por horas normal de cada empleado
        
        for (int i = 0; i < 3; i++) {
            if (vectorH[i]<=40){
                vectorT[i]=vectorH[i]*tarifa_normaL;    
            }
            else if (vectorH[i]>40){
                tarifa_media=(int) (tarifa_normaL+(0.50*tarifa_normaL));
                tarifaplus=vectorT[i]+tarifa_media;
                hora_extra=vectorH[i]-40;
                sueldo_total=(hora_extra*tarifaplus)+(40*tarifa_normaL);
                
            }
            System.out.println("el sueldo total a ganar del trabajor "+vectorE[i]+" es: "+sueldo_total);
            
           
        }
        
        
        
    }
    
}
